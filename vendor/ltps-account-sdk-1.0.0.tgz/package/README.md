# 利澤國小校級統一帳號管理中心（`ltps-account-hub` / `@ltps/account-sdk`）

本專案將校務系統的帳號管理從單一業務系統抽離，建立獨立的校級帳號機制，包含：

1. **獨立具名 Firestore 資料庫（`ltps-accounts`）**：集中管理全校教職員主檔、已註冊系統清單（`/apps`）與跨系統稽核紀錄（`/accountLogs`）。
2. **雙層分權後端模組（Cloud Functions Codebase：`ltps-accounts`）**：
   - 統一的 Firebase Auth Blocking Functions（`accounts_beforeCreate` / `accounts_beforeSignIn`）。
   - 嚴格區分「**校級超級管理員**（全校主檔、跨系統授權、全校停用、系統註冊）」與「**單一系統管理員**（僅能管理本系統角色、模組與本系統停權）」。
   - 自動同步精簡 **Custom Claims**（1,000 bytes 內），讓所有業務系統的 `firestore.rules` 免查表直接驗證權限。
3. **跨系統共用前端套件（`@ltps/account-sdk`）**：
   - `@ltps/account-sdk/core`：無框架依賴核心（Auth 流程、Custom Claims 解析、Callable API、Excel 範本解析）。
   - `@ltps/account-sdk/react`：相容 React 18 / 19、無 CSS 框架依賴的 `<LtpsAuthProvider>` 與統一嵌入式帳號管理元件 `<LtpsAccountManager />`。
4. **獨立網址的全校帳號管理後台（`console/`）**：可透過 Firebase Hosting Multi-site 部署至獨立網域（如 `https://ltps-accounts.web.app`）。

---

## 新系統如何呼叫本模組？

### 1. 安裝套件

```bash
npm install github:mihsia/ltps-account-hub
```

### 2. 在應用程式中整合登入與權限

```tsx
import '@ltps/account-sdk/styles.css';
import { LtpsAuthProvider, useLtpsAuth, LtpsAccountManager } from '@ltps/account-sdk/react';
import { auth, functions, accountsDb } from './firebase';

export function App() {
  return (
    <LtpsAuthProvider auth={auth} functions={functions} accountsDb={accountsDb} appId="patrol">
      <Main />
    </LtpsAuthProvider>
  );
}

function AccountPage() {
  const { user } = useLtpsAuth();
  return (
    <LtpsAccountManager
      mode="app"
      appId="patrol"
      functions={functions}
      currentUid={user?.uid}
      hubUrl="https://ltps-accounts.web.app"
    />
  );
}
```

### 3. 在業務系統的 `firestore.rules` 直接驗 Custom Claims（零額外讀取計費）

```javascript
function isGlobalActive() {
  return request.auth != null && request.auth.token.g == 1;
}
function isSuperAdmin() {
  return isGlobalActive() && request.auth.token.sa == 1;
}
function isPatrolUser() {
  return isGlobalActive() && (isSuperAdmin() || 'patrol' in request.auth.token.apps);
}
function isPatrolAdmin() {
  return isGlobalActive() && (isSuperAdmin() || request.auth.token.apps.patrol.r == 'a');
}
```

---

## 首次部署與從財務系統零停機遷移步驟

```bash
# 1. 建立獨立具名資料庫與獨立 Hosting 站台（只需執行一次）
gcloud firestore databases create --database=ltps-accounts --location=asia-east1 --project=ltps-finance-budget
firebase hosting:sites:create ltps-accounts --project=ltps-finance-budget

# 2. 建置並部署規則、後端函式（獨立 codebase）與全校帳號後台
npm run build
firebase deploy --only firestore:ltps-accounts,functions:ltps-accounts,hosting:accounts

# 3. 初始化系統註冊表並預覽／執行財務系統既有帳號遷移
npm run init:apps
npm run migrate:finance:dry-run
npm run migrate:finance
```
